window.onload = setTimeout;
setTimeout(function(){
    window.location.href = "modules/session_out.php";}, 15 * 60000);